% APH
SVM_Multi('APH_Month.mat','Months')