% AH
SVM_Multi('AH_Week.mat','Weeks')