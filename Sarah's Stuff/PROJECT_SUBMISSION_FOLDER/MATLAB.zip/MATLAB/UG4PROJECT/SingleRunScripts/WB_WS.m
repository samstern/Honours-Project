% WS
SVM_Binary('WS.mat','Weeks')