% SAPHH
SVM_Multi('SAPHH_Week.mat','Weeks')