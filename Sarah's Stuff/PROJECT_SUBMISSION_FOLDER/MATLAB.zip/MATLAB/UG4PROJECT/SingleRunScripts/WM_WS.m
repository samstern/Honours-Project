% WS
SVM_Multi('WS.mat','Weeks')