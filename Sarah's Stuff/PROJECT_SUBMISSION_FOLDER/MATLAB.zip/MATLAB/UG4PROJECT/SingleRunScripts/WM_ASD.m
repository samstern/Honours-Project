% ASD
SVM_Multi('ASD_Week.mat','Weeks')