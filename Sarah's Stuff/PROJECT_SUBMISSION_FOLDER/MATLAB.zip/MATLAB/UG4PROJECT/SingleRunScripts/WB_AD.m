% AD
SVM_Binary('AD_Week.mat','Weeks')