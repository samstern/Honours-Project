% SAPH
SVM_Multi('SAPH_Week.mat','Weeks')