% SAPHH
SVM_Binary('SAPHH_Week.mat','Weeks')