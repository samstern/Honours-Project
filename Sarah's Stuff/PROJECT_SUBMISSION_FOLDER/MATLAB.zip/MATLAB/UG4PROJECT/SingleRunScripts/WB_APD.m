% APD
SVM_Binary('APD_Week.mat','Weeks')