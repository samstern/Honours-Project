% AHHD
SVM_Multi('AHHD_Week.mat','Weeks')