% AHH
SVM_Binary('AHH_Week.mat','Weeks')