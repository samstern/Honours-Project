% AHD
SVM_Binary('AHD_Week.mat','Weeks')