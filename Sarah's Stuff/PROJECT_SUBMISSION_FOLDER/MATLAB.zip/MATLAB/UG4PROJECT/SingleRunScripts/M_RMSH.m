% Recreated_Month_Simple_Hour
SVM_Multi('Recreated_Month_Simple_Hour.mat','Months')