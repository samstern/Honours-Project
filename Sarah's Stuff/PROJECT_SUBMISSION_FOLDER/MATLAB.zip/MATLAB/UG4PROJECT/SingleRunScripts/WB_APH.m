% APH
SVM_Binary('APH_Week.mat','Weeks')