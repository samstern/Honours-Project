% Recreated_Week_Simple_Hour
SVM_Multi('Recreated_Week_Simple_Hour','Weeks')