% ASD
SVM_Binary('ASD_Week.mat','Weeks')