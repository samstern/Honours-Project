% Recreated_Week_Simple_Half_Hour
SVM_Multi('Recreated_Week_Simple_Half_Hour.mat','Weeks')