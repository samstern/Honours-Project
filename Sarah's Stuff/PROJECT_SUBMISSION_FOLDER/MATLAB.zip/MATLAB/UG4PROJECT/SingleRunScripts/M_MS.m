% MS
SVM_Multi('MS.mat','Months')