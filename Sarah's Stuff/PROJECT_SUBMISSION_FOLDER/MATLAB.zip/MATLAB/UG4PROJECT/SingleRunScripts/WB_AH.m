% AH
SVM_Binary('AH_Week.mat','Weeks')