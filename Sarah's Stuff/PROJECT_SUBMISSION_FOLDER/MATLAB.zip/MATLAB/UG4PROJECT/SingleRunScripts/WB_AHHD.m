% AHHD
SVM_Binary('AHHD_Week.mat','Weeks')