% SAPD
SVM_Binary('SAPD_Week.mat','Weeks')