% AHH
SVM_Multi('AHH_Week.mat','Weeks')