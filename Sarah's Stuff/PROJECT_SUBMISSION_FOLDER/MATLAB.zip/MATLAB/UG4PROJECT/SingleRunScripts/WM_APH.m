% APH
SVM_Multi('APH_Week.mat','Weeks')