% SAPH
SVM_Multi('SAPH_Month.mat','Months'