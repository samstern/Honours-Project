cd /afs/inf.ed.ac.uk/user/s09/s0955035/Feature' Selection Package'/fspackage/
load_fspackage
cd /afs/inf.ed.ac.uk/user/s09/s0955035/Desktop/UG4PROJECT