% SAPD
SVM_Multi('SAPD_Week.mat','Weeks')