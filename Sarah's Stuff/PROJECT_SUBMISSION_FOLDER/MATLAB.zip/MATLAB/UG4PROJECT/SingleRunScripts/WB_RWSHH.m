% Recreated_Week_Simple_Half_Hour
SVM_Binary('Recreated_Week_Simple_Half_Hour.mat','Weeks')