% SAPHH
SVM_Multi('SAPHH_Month.mat','Months')