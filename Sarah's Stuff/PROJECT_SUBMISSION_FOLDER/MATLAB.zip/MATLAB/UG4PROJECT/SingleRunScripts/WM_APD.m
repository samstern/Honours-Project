% APD
SVM_Multi('APD_Week.mat','Weeks')