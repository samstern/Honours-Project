% APHH
SVM_Multi('APHH_Month.mat','Months')