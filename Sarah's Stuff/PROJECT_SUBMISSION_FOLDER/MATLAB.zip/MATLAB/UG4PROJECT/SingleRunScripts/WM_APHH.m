% APHH
SVM_Multi('APHH_Week.mat','Weeks')