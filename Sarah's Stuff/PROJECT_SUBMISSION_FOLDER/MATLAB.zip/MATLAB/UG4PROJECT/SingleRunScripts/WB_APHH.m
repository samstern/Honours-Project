% APHH
SVM_Binary('APHH_Week.mat','Weeks')