% Recreated_Month_Simple_Half_Hour
SVM_Multi('Recreated_Month_Simple_Half_Hour.mat','Months')