% AHD
SVM_Multi('AHD_Week.mat','Weeks')