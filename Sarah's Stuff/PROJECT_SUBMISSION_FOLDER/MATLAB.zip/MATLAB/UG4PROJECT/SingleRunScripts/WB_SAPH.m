% SAPH
SVM_Binary('SAPH_Week.mat','Weeks')