In UG$_PROJECT there are folders and scripts where (hopefully) the names are evient of what the script does or the folder contains.

the folder 'features' contains the features and classlabels in matrix and vector format.

'WholeModelling.m' is a script that runs all models on all features.

Can run functions on a feature. these use one model and produce results for this one feature set.


