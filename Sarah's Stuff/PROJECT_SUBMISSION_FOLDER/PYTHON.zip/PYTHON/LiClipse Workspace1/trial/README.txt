These foldernames represent the databases used to create the features.

Example: Total_Profile_Monthly buids featuers on the monthly dataset tables that had the entries for the tables calculated using the appliance readings that make up to the total profile
