Folder1: MATLAB_RESULTS_FOLDER
This folder contains the graphs, and graphin runctions used to create the figures in the project

Folder2: Results
This containts txt files of the output from the matlab modelling
